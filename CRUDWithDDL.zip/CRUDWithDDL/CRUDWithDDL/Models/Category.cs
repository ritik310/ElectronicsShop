﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CRUDWithDDL.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }

        [DisplayName("Category")]
        public string CategoryName { get; set; }
    }
}
